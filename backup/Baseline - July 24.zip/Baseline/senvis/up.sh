scp -rp * ducduy.nguyen@cassandra.disi.unitn.it:/data/www/SocialMediaSummarization
